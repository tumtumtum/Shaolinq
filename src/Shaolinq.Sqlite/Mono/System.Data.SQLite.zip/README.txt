Shaolinq.Sqlite for Mono

The System.Data.SQLite.dll included in the zip file is built for mono. The system will need to have an up to date build of sqlite3 (libsqlite3.so.0) available in a directory referenced by LD_LIBRARY_PATH.